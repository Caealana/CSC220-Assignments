function Checkboxes(labels){
    this.labels = labels;
}

Checkboxes.prototype.createCheckboxes = function(){
    
}


