function SelectorManager(dataSeries){
    this.selectors = [];
    this.dataSeries = dataSeries; //comprehensive list of dataSeries
}

SelectorManager.prototype.initializeSelectors = function(){
    
}

