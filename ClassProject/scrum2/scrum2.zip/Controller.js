function Controller(graphArea){
    this.dataManager;
    this.dataSeries;
    this.graphArea = graphArea;
    this.selectorManager;
}

Controller.prototype.initialGraphSetup = function(){
    
}


