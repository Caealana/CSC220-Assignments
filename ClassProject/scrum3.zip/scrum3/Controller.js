/**
 * Controls what is displayed on the page
 * @constructor
 * @param {GraphArea} graphArea
 * @returns {Controller}
 */
function Controller(graphArea){
    this.dataManager;
    this.dataSeries;
    this.graphArea = graphArea;
    this.selectorManager;
    this.sliders;
}

Controller.prototype.initialGraphSetup = function(){
    
}


