function SelectorManager(){
    this.selectors = [];
    this.dataSeries;
}

SelectorManager.prototype.initializeSelectors = function(){
    
}

