function SmithEnergySelector(){
    
}

SmithEnergySelector.prototype = new Selector();


